Windows driver for USBasp based on libusb
-----------------------------------------

The files in this archive are generated with libusb_0.1.12.1 (http://libusb-win32.sourceforge.net).
If you use WinAVR, version 20080512 or greater is needed.

More information on USBasp: http://www.fischl.de/usbasp
2009-02-28
